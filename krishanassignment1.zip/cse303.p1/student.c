
#include "support.h"

/*
 * Please be sure to fill in this struct right away!
 */
struct student_t student = {
  "Krishan Madan", /* first member name, e.g., Michael Spear */
  "krm219@lehigh.edu"  /* first member email, e.g., mfs409@lehigh.edu */
};
